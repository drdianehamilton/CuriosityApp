function App() { return <div>Hello from Curiosity App</div>; }
export default App;